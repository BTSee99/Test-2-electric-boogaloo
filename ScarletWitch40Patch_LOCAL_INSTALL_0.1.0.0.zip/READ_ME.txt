SCARLET WITCH - LEVEL 40 PATCH / PRIVATE WINDOWS INSTALL / 0.1.0.0

This is a SEPARATE mod. Keep the original Scarlet Witch, its dependencies
(including Telekinetic Spells), and Beyond Twelve - Level 40 installed.
Use Beyond Twelve version 0.3.0.1 or later.

1. Close Baldur's Gate 3 completely.
2. Extract the entire ZIP. Open the extracted folder.
3. Double-click INSTALL.cmd. No administrator access is needed.
4. Start BG3 > Mod Manager > Installed. Clear search/filter settings.
5. Enable Scarlet Witch - Level 40 Patch AND both original mods.
6. Load a COPY of the save from before the failed level-up and try 12 to 13.

If using an external load-order manager, load this patch AFTER Scarlet Witch
and Beyond Twelve. The patch declares both as dependencies in its metadata.

The installer checks the package checksum and copies ONLY the patch to:
%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Mods

It backs up older ScarletWitch40Patch versioned files outside Mods, into a
ScarletWitch40Patch-Backups folder next to Mods. It does not move or replace
Scarlet Witch, Beyond Twelve, other mods, saved games or load-order settings.
INSTALL.cmd allows its PowerShell script for this process only; it does
not change the computer's saved PowerShell execution policy.

MANUAL INSTALL
Copy ScarletWitch40Patch_0.1.0.0.pak directly into the Mods folder above,
then enable it in the game's Installed tab. Remove older versions of this
PATCH first. Keep the original class mod and level-cap mod installed.

WHAT IT ADDS
- The uploaded Scarlet Witch class stops at 12. This patch adds 13 through 40.
- A feat/ability-improvement choice at EVERY Scarlet Witch class level 13-40.
- Full-caster spell slots, preserving the original extra sixth-tier slot.
- Custom slot growth above 20, matching Beyond Twelve's full-caster curve.
- Two more Reality Threads at each even class level (40 capacity at level 40).
- No added spell-selection step, so no unavailable new spell must be chosen.
Beyond Twelve continues handling 1 XP per level-up, 39 total XP to level 40.

The patch does not introduce new spells, high-tier upcast definitions, epic
abilities or custom damage scaling. Existing class content comes from the
original mod. No original artwork, spell definitions or story scripts are
included in this ZIP. The original Scarlet Witch author is danliyev.

TEST STATUS
Source, package and installer checks passed. The actual black-screen fix
still needs testing in BG3. This was built against uploaded Scarlet Witch
version 1.0.0.26; other releases have not been inspected. Test levels 13-40,
save/load, respec, prepared spells, custom abilities and rest recovery.

UNINSTALL ONLY THIS PATCH
Close BG3. Remove ScarletWitch40Patch_0.1.0.0.pak from the Mods folder.
Leave the original Scarlet Witch and Beyond Twelve installed if wanted.
Do not continue leveling Scarlet Witch above 12 without a compatible patch.

IF IT DOES NOT APPEAR
Restart BG3 and check Installed, not the online Browse list. Confirm the
.pak is directly inside Mods for the Windows account running BG3. If the
game reports missing dependencies, check all required mods are enabled.
Share the game version and exact error if the patch is rejected.
