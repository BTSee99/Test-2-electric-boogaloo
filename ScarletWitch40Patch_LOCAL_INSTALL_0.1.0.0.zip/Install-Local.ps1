param([string]$ModsDirectory)

# Windows PowerShell 5.1 compatible. Installs only the bundled release.
# -ModsDirectory is an optional override for portable installs and file tests.
$ErrorActionPreference = 'Stop'
$packageName = 'ScarletWitch40Patch_0.1.0.0.pak'
$expectedHash = 'A64517B80A354DE6893D5A3C6527C7CF9A48EB0D791A95BEB6737EC343615AAA'
$stagingFile = $null
$moved = @()
$committed = $false

function Get-PackageHash([string]$File) {
    $stream = [IO.File]::OpenRead($File)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-', '')
    } finally {
        $stream.Dispose()
        $hasher.Dispose()
    }
}

function Assert-DirectChild([string]$File, [string]$Directory) {
    $parent = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($File))
    $expected = [IO.Path]::GetFullPath($Directory).TrimEnd([IO.Path]::DirectorySeparatorChar)
    if (-not $parent.Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to move a file outside the intended folder: $File"
    }
}

try {
    $source = Join-Path $PSScriptRoot $packageName
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw 'The mod package is missing. Extract ALL files from the ZIP into one folder first.'
    }
    if ((Get-PackageHash $source) -ne $expectedHash) {
        throw 'The package checksum does not match this release. Extract a fresh copy of the ZIP.'
    }
    if (Get-Process -Name 'bg3', 'bg3_dx11' -ErrorAction SilentlyContinue) {
        throw "Close Baldur's Gate 3, then run INSTALL.cmd again."
    }
    if ([string]::IsNullOrWhiteSpace($ModsDirectory)) {
        $localData = [Environment]::GetFolderPath('LocalApplicationData')
        if ([string]::IsNullOrWhiteSpace($localData)) { throw 'Windows did not provide a Local AppData folder.' }
        $ModsDirectory = Join-Path $localData "Larian Studios\Baldur's Gate 3\Mods"
    }
    $ModsDirectory = [IO.Path]::GetFullPath($ModsDirectory)
    New-Item -ItemType Directory -Path $ModsDirectory -Force | Out-Null
    $ModsDirectory = (Resolve-Path -LiteralPath $ModsDirectory).ProviderPath
    $destination = Join-Path $ModsDirectory $packageName
    if (Test-Path -LiteralPath $destination -PathType Container) {
        throw "A folder has the package's filename. Move it out of Mods and try again: $destination"
    }
    $existing = @(Get-ChildItem -LiteralPath $ModsDirectory -File | Where-Object {
        $_.Name -match '^ScarletWitch40Patch_(\d+\.\d+\.\d+\.\d+)\.pak$'
    })

    if ($existing.Count -eq 1 -and $existing[0].Name -eq $packageName -and
        (Get-PackageHash $destination) -eq $expectedHash) {
        Write-Host 'This release is already installed.' -ForegroundColor Green
    } else {
        # Validate a staged copy before moving any previous builds.
        $stagingFile = Join-Path $ModsDirectory ('.ScarletWitch40Patch-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        Copy-Item -LiteralPath $source -Destination $stagingFile
        if ((Get-PackageHash $stagingFile) -ne $expectedHash) {
            throw 'The copied package failed verification. The previous installation has not been changed.'
        }
        if ($existing.Count -gt 0) {
            # Keep old versions OUTSIDE Mods so the game cannot load duplicate module IDs.
            $backupRoot = Join-Path ([IO.Directory]::GetParent($ModsDirectory).FullName) 'ScarletWitch40Patch-Backups'
            $backup = Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
            Assert-DirectChild $backup $backupRoot
            New-Item -ItemType Directory -Path $backup -Force | Out-Null
            foreach ($previous in $existing) {
                $backupFile = Join-Path $backup $previous.Name
                Assert-DirectChild $previous.FullName $ModsDirectory
                Assert-DirectChild $backupFile $backup
                Move-Item -LiteralPath $previous.FullName -Destination $backupFile
                $moved += [pscustomobject]@{ Original = $previous.FullName; Backup = $backupFile }
            }
        }
        Assert-DirectChild $stagingFile $ModsDirectory
        Assert-DirectChild $destination $ModsDirectory
        Move-Item -LiteralPath $stagingFile -Destination $destination
        $committed = $true
        Write-Host 'Scarlet Witch - Level 40 Patch (0.1.0.0) installed.' -ForegroundColor Green
        if ($moved.Count -gt 0) { Write-Host "Previous builds backed up to: $backup" }
    }
    Write-Host "Mod folder: $ModsDirectory"
    Write-Host ''
    Write-Host 'NEXT: Launch BG3 > Mod Manager > Installed.'
    Write-Host 'Enable this patch, Scarlet_Witch and Beyond Twelve - Level 40.'
    Write-Host 'This patch: Scarlet Witch levels 13-40, feats, spell slots and Reality Threads.'
    Write-Host 'This is a test release; gameplay has not yet been verified.'
    Write-Host 'Nothing was published or uploaded.'
} catch {
    Write-Host ("Installation failed: " + $_.Exception.Message) -ForegroundColor Red
    if (-not $committed) {
        foreach ($entry in $moved) {
            try {
                if (-not (Test-Path -LiteralPath $entry.Original)) {
                    Assert-DirectChild $entry.Original $ModsDirectory
                    Assert-DirectChild $entry.Backup $backup
                    Move-Item -LiteralPath $entry.Backup -Destination $entry.Original
                }
            } catch {
                Write-Host ("Restore this backup manually: " + $entry.Backup) -ForegroundColor Yellow
            }
        }
    }
    exit 1
} finally {
    if ($stagingFile -and (Test-Path -LiteralPath $stagingFile -PathType Leaf)) {
        Assert-DirectChild $stagingFile $ModsDirectory
        Remove-Item -LiteralPath $stagingFile
    }
}
