@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Local.ps1"
set "installResult=%errorlevel%"
echo.
pause
exit /b %installResult%
